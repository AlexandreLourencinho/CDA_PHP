create definer = root@localhost trigger maj_total_delete
    after delete
    on lignedecommande
    for each row
BEGIN
DECLARE id_c INT;
DECLARE tot DOUBLE;
SET id_c = old.id_commande;
SET tot = (SELECT sum(prix*quantite) FROM lignedecommande WHERE id_commande=id_c); -- on recalcul le total
UPDATE commande SET total=tot WHERE id=id_c; -- on stocke le total dans la table commande
END;

