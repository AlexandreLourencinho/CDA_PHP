create definer = root@localhost trigger maj_total_update
    after update
    on lignedecommande
    for each row
BEGIN
        DECLARE id_c INT;
        DECLARE tot DOUBLE;
        DECLARE id_p INT;
        SET id_c = new.id_commande; -- nous captons le numéro de commande concerné
        SET id_p= NEW.id_produit;
        IF ((SELECT NEW.quantite FROM lignedecommande WHERE id_c = id_commande AND id_produit=id_p)<>(select OLD.quantite from lignedecommande WHERE id_c = id_commande AND id_produit=id_p)) 
		  THEN
        SET tot = (SELECT sum(prix*new.quantite) FROM lignedecommande WHERE id_commande = id_c AND id_produit=id_p); -- on recalcul le total
        UPDATE commande SET total = tot WHERE id = id_c; -- on stocke le total dans la table commande        
        ELSEIF ((SELECT NEW.prix FROM lignedecommande WHERE id_c = id_commande AND id_produit=id_p)<>(select OLD.prix from lignedecommande WHERE id_c = id_commande AND id_produit=id_p)) 
		  THEN
        SET tot = (SELECT sum(new.prix*quantite) FROM lignedecommande WHERE id_commande = id_c); -- on recalcul le total
        UPDATE commande SET total = tot WHERE id = id_c; -- on stocke le total dans la table commande        
        ELSE 
		  SET tot = (SELECT sum(prix*quantite) FROM lignedecommande WHERE id_commande = id_c AND id_produit=id_p); 
        UPDATE commande SET total = tot WHERE id = id_c;
        END IF;
END;

